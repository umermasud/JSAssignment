## JS chapter 5,6,7
Java-script assignments chapter 5, 6, 7

1. declare a variable for Number 'a' ```for example a value is 2```
2. declare a variable for Number 'b'  ```for example b value is a++ + ++a - --a + a--```
3. print meassage in alert() ```variable a``` 
4. print meassage in alert() ```variable b``` 