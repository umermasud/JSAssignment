var birthYear = 1993;

document.write("My Birth year is = " + birthYear);
document.write("\nData type of my declared variable is number");