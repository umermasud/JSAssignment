var Name = 'Umer Masood';
var age = 27;
var Job = 'Certified Application developer';

alert('My name is = ' + Name);
alert("I am " + age + " years old ");
alert(Job);