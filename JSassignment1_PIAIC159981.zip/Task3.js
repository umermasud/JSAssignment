var email = "umer_masud@hotmail.com";
alert("My email address is " + email);