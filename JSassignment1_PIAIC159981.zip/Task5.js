var age = 27;
alert("I am " + age + " years old ");