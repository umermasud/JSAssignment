## JS chapter 31 to 34
Java-script assignments chapter 31 to 34

1. input your name through prompt. 		
``` for example name is  "Ameen Alam" ```
2. input your DOB(date) through prompt. 	
``` for example date is  "24" ```
3. input your DOB(month) through prompt.	
``` for example month is  "05" ```
4. input your DOB(year) through prompt. 	
``` for example year is  "1999" ```


5. print meassage in console.log()
   ``` "Hello Ameen Alam, Good Morning, AfterNoon, Evening or Night" ```

6. print meassage in console.log()
   ``` "Your DOB is {in pakistan standard time format}" ```

7. print meassage in console.log()
   ``` "You are 20 years 7 Month 10 Days 19 Hours 20 Minutes 25 Seconds old" ```

   ``` "Your Age in Days 7510" ```

8. print meassage in console.log()
   ``` "How much time left in your next birthday? 161 days 4 hours 39 minutes 34 seconds" ```
    or
   ``` "happy Birth Day Ameen Alam.  Today is Your 20th Birthday" ```