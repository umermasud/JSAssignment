## JS chapter 18 19 20
Java-script assignments chapter 18 19 20

#### Make a TODO
Customize previous assignment "ch_15_16_17" with for loop...