## JS chapter 1,2,3
Java-script assignments chapter 1, 2, 3

1. declare a variable for String 'firstName' ```for example firstName is "Ameen"```
2. declare a variable for String 'lasName'  ```for example lasName is "Alam"```
3. declare a variable for Number 'age' ```for example age is 20```

4. print meassage in alert() ```Hello Ameen Alam, You are 20 years old``` 